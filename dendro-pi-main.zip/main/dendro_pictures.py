from picamera import PiCamera
from time import sleep
from datetime import datetime

PICTURES_PATH = "/home/pi/dendro-pi/pictures/"
CAMERA_NAME = ""  # Edit this to change name picture file


def get_filename():
    return CAMERA_NAME + get_date_and_time() + ".jpg"


def get_date_and_time():
    return str(datetime.now().year) + "-" + \
           str(datetime.now().month) + "-" + \
           str(datetime.now().day) + "-" + \
           str(datetime.now().hour)


def take_picture():
    camera = PiCamera()
    setup_camera(camera)
    camera.capture(PICTURES_PATH + get_filename())
    camera.close()


def setup_camera(camera):
    camera.resolution = (2592, 1944)
    camera.start_preview()
    sleep(2)  # Camera warm-up time


if __name__ == '__main__':
    take_picture()
