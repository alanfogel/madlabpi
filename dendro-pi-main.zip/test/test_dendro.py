import os
import sys
import unittest

sys.path.append("../main")
import dendro_pictures


class TestDendro(unittest.TestCase):
    def test_picture(self):
        dendro_pictures.take_picture()
        filename = dendro_pictures.get_filename()
        picture_files = os.listdir("../pictures/")
        self.assertTrue(any(filename == file for file in picture_files))
        os.remove("../pictures/"+filename)


if __name__ == '__main__':
    unittest.main()
